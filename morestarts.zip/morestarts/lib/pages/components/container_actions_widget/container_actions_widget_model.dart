import '/flutter_flow/flutter_flow_util.dart';
import 'container_actions_widget_widget.dart' show ContainerActionsWidgetWidget;
import 'package:flutter/material.dart';

class ContainerActionsWidgetModel
    extends FlutterFlowModel<ContainerActionsWidgetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
