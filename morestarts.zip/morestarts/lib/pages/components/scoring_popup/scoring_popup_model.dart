import '/flutter_flow/flutter_flow_util.dart';
import 'scoring_popup_widget.dart' show ScoringPopupWidget;
import 'package:flutter/material.dart';

class ScoringPopupModel extends FlutterFlowModel<ScoringPopupWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
