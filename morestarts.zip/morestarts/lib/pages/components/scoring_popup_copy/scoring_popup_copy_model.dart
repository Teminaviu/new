import '/flutter_flow/flutter_flow_util.dart';
import 'scoring_popup_copy_widget.dart' show ScoringPopupCopyWidget;
import 'package:flutter/material.dart';

class ScoringPopupCopyModel extends FlutterFlowModel<ScoringPopupCopyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
